# CHAAMAS — V3 Authentification

Ce lot remplace l'ancienne maquette OTP SMS par un parcours réel préparé pour Firebase :
- création de compte avec nom, téléphone international (+229 par défaut), e-mail et mot de passe ;
- vérification d'adresse par lien e-mail ;
- connexion avec téléphone + mot de passe ;
- profil privé dans Firestore et rôle initial `member` (jamais administrateur par défaut).

## 1. Pré-requis
Flutter stable, Node.js 20, Firebase CLI et FlutterFire CLI. Crée un projet Firebase puis active **Authentication > Email/Password** et **Cloud Firestore**.

## 2. Configuration Flutter
Depuis le dossier du projet :
```bash
dart pub global activate flutterfire_cli
flutterfire configure
flutter pub get
```
La commande `flutterfire configure` génère `lib/firebase_options.dart` et relie les applications Android/iOS au projet Firebase. Le code initialise Firebase avec `DefaultFirebaseOptions.currentPlatform`.

## 3. Déployer les fonctions serveur
```bash
cd functions
npm install
npm run build
cd ..
firebase init functions firestore
firebase deploy --only functions,firestore:rules
```
Choisis TypeScript et conserve le dossier `functions` existant. Le fichier `functions/src/index.ts` expose `registerWithPhone` et `loginWithPhone`.

## 4. Règles Firestore indispensables
Le hash du mot de passe est stocké dans `authSecrets`, une collection serveur inaccessible au client. Déployer ces règles avant les essais :
```bash
firebase deploy --only firestore:rules
```

## Important — sécurité avant production
Ce code est un socle de développement, pas une version prête à publier. Il faut encore activer Firebase App Check, limiter les tentatives de connexion et d'inscription, ajouter une protection anti-abus, vérifier les transactions contre les inscriptions concurrentes, maintenir `authSecrets` strictement inaccessible aux clients, écrire des règles Firestore strictes, gérer suppression/export de compte et tester les liens e-mail sur Android/iOS. Ne jamais rendre les collections `phoneAccounts`, `emailAccounts` ou les hashes lisibles par les clients. Pour la production, renforcer la fonction avec des transactions et un contrôle d'identité de l'application.

## Parcours fonctionnel
Après inscription, le backend crée l'utilisateur Firebase, associe le numéro et génère une session. Firebase envoie ensuite un lien de vérification e-mail. Tant que l'adresse n'est pas vérifiée, l'accès à l'espace principal reste bloqué. La connexion se fait par numéro international et mot de passe.
