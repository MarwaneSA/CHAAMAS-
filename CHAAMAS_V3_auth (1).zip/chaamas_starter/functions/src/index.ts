import {onCall, HttpsError} from 'firebase-functions/v2/https';
import {initializeApp} from 'firebase-admin/app';
import {getAuth} from 'firebase-admin/auth';
import {getFirestore, FieldValue} from 'firebase-admin/firestore';
import * as bcrypt from 'bcryptjs';

initializeApp();
const db = getFirestore();
const normalizePhone = (value: unknown): string => {
  if (typeof value !== 'string') throw new HttpsError('invalid-argument', 'Numéro invalide.');
  const phone = value.replace(/[^0-9+]/g, '');
  if (!/^\+[1-9][0-9]{7,14}$/.test(phone)) throw new HttpsError('invalid-argument', 'Utilise un numéro international valide.');
  return phone;
};

export const registerWithPhone = onCall({enforceAppCheck: false}, async (request) => {
  const phone = normalizePhone(request.data.phone);
  const email = String(request.data.email ?? '').trim().toLowerCase();
  const password = String(request.data.password ?? '');
  const displayName = String(request.data.displayName ?? '').trim();
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) throw new HttpsError('invalid-argument', 'Adresse e-mail invalide.');
  if (password.length < 8 || displayName.length < 2) throw new HttpsError('invalid-argument', 'Informations de compte insuffisantes.');
  const phoneRef = db.collection('phoneAccounts').doc(phone);
  const emailRef = db.collection('emailAccounts').doc(email);
  const [phoneSnap, emailSnap] = await Promise.all([phoneRef.get(), emailRef.get()]);
  if (phoneSnap.exists) throw new HttpsError('already-exists', 'Ce numéro est déjà associé à un compte.');
  if (emailSnap.exists) throw new HttpsError('already-exists', 'Cette adresse e-mail est déjà utilisée.');
  let user;
  try {
    user = await getAuth().createUser({email, password, displayName, emailVerified: false, disabled: false});
    const passwordHash = await bcrypt.hash(password, 12);
    const batch = db.batch();
    batch.set(phoneRef, {uid: user.uid, createdAt: FieldValue.serverTimestamp()});
    batch.set(emailRef, {uid: user.uid});
    batch.set(db.collection('users').doc(user.uid), {uid: user.uid, phone, email, displayName, emailVerified: false, role: 'member', creatorApproved: false, createdAt: FieldValue.serverTimestamp()});
    batch.set(db.collection('authSecrets').doc(user.uid), {passwordHash});
    await batch.commit();
    const token = await getAuth().createCustomToken(user.uid);
    return {token};
  } catch (error) {
    if (user) await getAuth().deleteUser(user.uid).catch(() => undefined);
    console.error('registerWithPhone failed', error);
    throw new HttpsError('internal', 'La création du compte a échoué. Réessaie.');
  }
});

export const loginWithPhone = onCall({enforceAppCheck: false}, async (request) => {
  const phone = normalizePhone(request.data.phone);
  const password = String(request.data.password ?? '');
  const snap = await db.collection('phoneAccounts').doc(phone).get();
  if (!snap.exists) throw new HttpsError('unauthenticated', 'Numéro ou mot de passe incorrect.');
  const uid = String(snap.get('uid'));
  const profile = await db.collection('users').doc(uid).get();
  const secret = await db.collection('authSecrets').doc(uid).get();
  const hash = secret.get('passwordHash');
  if (typeof hash !== 'string' || !(await bcrypt.compare(password, hash))) throw new HttpsError('unauthenticated', 'Numéro ou mot de passe incorrect.');
  const token = await getAuth().createCustomToken(uid);
  return {token};
});
