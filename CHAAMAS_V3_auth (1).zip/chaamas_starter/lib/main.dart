import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:intl_phone_field/intl_phone_field.dart';

const purple = Color(0xFF7657E8);
const dark = Color(0xFF10152B);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(const ChaamasApp());
}

class ChaamasApp extends StatelessWidget {
  const ChaamasApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'CHAAMAS', debugShowCheckedModeBanner: false,
    theme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: purple), scaffoldBackgroundColor: const Color(0xFFF7F7FB)),
    home: const AuthGate(),
  );
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});
  @override
  Widget build(BuildContext context) => StreamBuilder<User?>(
    stream: FirebaseAuth.instance.authStateChanges(),
    builder: (context, snapshot) {
      if (snapshot.connectionState == ConnectionState.waiting) return const Scaffold(body: Center(child: CircularProgressIndicator()));
      final user = snapshot.data;
      if (user == null) return const AuthPage();
      if (!user.emailVerified) return VerifyEmailPage(email: user.email ?? '');
      return const MainShell();
    },
  );
}

class AuthService {
  final _functions = FirebaseFunctions.instance;
  Future<void> register({required String phone, required String email, required String password, required String displayName}) async {
    final callable = _functions.httpsCallable('registerWithPhone');
    final result = await callable.call({'phone': phone, 'email': email.trim().toLowerCase(), 'password': password, 'displayName': displayName.trim()});
    final token = result.data['token'] as String;
    await FirebaseAuth.instance.signInWithCustomToken(token);
    await FirebaseAuth.instance.currentUser!.sendEmailVerification();
  }
  Future<void> login({required String phone, required String password}) async {
    final callable = _functions.httpsCallable('loginWithPhone');
    final result = await callable.call({'phone': phone, 'password': password});
    await FirebaseAuth.instance.signInWithCustomToken(result.data['token'] as String);
  }
  Future<void> resendVerification() async => FirebaseAuth.instance.currentUser!.sendEmailVerification();
  Future<void> logout() => FirebaseAuth.instance.signOut();
}

class AuthPage extends StatefulWidget {
  const AuthPage({super.key});
  @override State<AuthPage> createState() => _AuthPageState();
}
class _AuthPageState extends State<AuthPage> {
  final _form = GlobalKey<FormState>();
  final _service = AuthService();
  final _phone = TextEditingController();
  final _email = TextEditingController();
  final _password = TextEditingController();
  final _name = TextEditingController();
  String _dial = '+229';
  bool _register = true, _busy = false, _hide = true;
  @override void dispose() { _phone.dispose(); _email.dispose(); _password.dispose(); _name.dispose(); super.dispose(); }
  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    setState(() => _busy = true);
    try {
      final phone = '$_dial${_phone.text.replaceAll(RegExp(r'[^0-9]'), '')}';
      if (_register) {
        await _service.register(phone: phone, email: _email.text, password: _password.text, displayName: _name.text);
      } else {
        await _service.login(phone: phone, password: _password.text);
      }
    } on FirebaseFunctionsException catch (e) {
      _error(e.message ?? 'Impossible de traiter la demande.');
    } on FirebaseAuthException catch (e) {
      _error(e.message ?? 'Erreur de compte.');
    } catch (e) { _error('Une erreur est survenue. Vérifie ta connexion et réessaie.'); }
    finally { if (mounted) setState(() => _busy = false); }
  }
  void _error(String message) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  InputDecoration _dec(String label, IconData icon) => InputDecoration(labelText: label, prefixIcon: Icon(icon), filled: true, fillColor: Colors.white, border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none));
  @override Widget build(BuildContext context) => Scaffold(
    backgroundColor: dark,
    body: SafeArea(child: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(24), child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 440), child: Form(key: _form, child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const Icon(Icons.graphic_eq_rounded, color: Color(0xFFB9A9FF), size: 60), const SizedBox(height: 8),
      const Text('CHAAMAS', textAlign: TextAlign.center, style: TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.w900, letterSpacing: 2)),
      const SizedBox(height: 8), Text(_register ? 'Crée ton compte et rejoins la communauté.' : 'Heureux de te revoir !', textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70)), const SizedBox(height: 30),
      if (_register) ...[
        TextFormField(controller: _name, decoration: _dec('Nom complet', Icons.person_outline), validator: (v) => (v == null || v.trim().length < 2) ? 'Saisis ton nom.' : null), const SizedBox(height: 12),
        TextFormField(controller: _email, keyboardType: TextInputType.emailAddress, decoration: _dec('Adresse e-mail', Icons.email_outlined), validator: (v) => (v == null || !RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(v.trim())) ? 'Adresse e-mail invalide.' : null), const SizedBox(height: 12),
      ],
      Container(padding: const EdgeInsets.symmetric(horizontal: 12), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14)), child: IntlPhoneField(initialCountryCode: 'BJ', disableLengthCheck: true, decoration: const InputDecoration(labelText: 'Numéro de téléphone', border: InputBorder.none), onCountryChanged: (country) => _dial = '+${country.dialCode}', onChanged: (number) { _dial = '+${number.countryCode}'; _phone.text = number.number; },)),
      const SizedBox(height: 12), TextFormField(controller: _password, obscureText: _hide, decoration: _dec('Mot de passe', Icons.lock_outline).copyWith(suffixIcon: IconButton(onPressed: () => setState(() => _hide = !_hide), icon: Icon(_hide ? Icons.visibility : Icons.visibility_off))), validator: (v) => (v == null || v.length < 8) ? '8 caractères minimum.' : null),
      const SizedBox(height: 20), FilledButton(onPressed: _busy ? null : _submit, style: FilledButton.styleFrom(backgroundColor: purple, padding: const EdgeInsets.all(16)), child: _busy ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : Text(_register ? 'Créer mon compte' : 'Se connecter')),
      TextButton(onPressed: _busy ? null : () => setState(() => _register = !_register), child: Text(_register ? 'J’ai déjà un compte — Connexion' : 'Créer un compte', style: const TextStyle(color: Colors.white))),
      const SizedBox(height: 12), const Text('La vérification du compte se fait par e-mail. Aucun code SMS n’est utilisé.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white60, fontSize: 12)),
    ]))))),
  );
}

class VerifyEmailPage extends StatelessWidget {
  final String email; const VerifyEmailPage({super.key, required this.email});
  @override Widget build(BuildContext context) => Scaffold(body: Center(child: Padding(padding: const EdgeInsets.all(28), child: Column(mainAxisSize: MainAxisSize.min, children: [
    const Icon(Icons.mark_email_unread_outlined, size: 64, color: purple), const SizedBox(height: 16), const Text('Vérifie ton adresse e-mail', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)), const SizedBox(height: 8), Text('Un lien de vérification a été envoyé à $email. Ouvre-le, puis reviens ici.'), const SizedBox(height: 20),
    FilledButton(onPressed: () async { await FirebaseAuth.instance.currentUser?.reload(); }, child: const Text('J’ai vérifié mon e-mail')),
    TextButton(onPressed: () async { await FirebaseAuth.instance.currentUser?.sendEmailVerification(); }, child: const Text('Renvoyer le lien')),
    TextButton(onPressed: () => FirebaseAuth.instance.signOut(), child: const Text('Se déconnecter')),
  ])))); }
}

class MainShell extends StatelessWidget {
  const MainShell({super.key});
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('CHAAMAS'), actions: [IconButton(onPressed: () => FirebaseAuth.instance.signOut(), icon: const Icon(Icons.logout))]), body: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.verified_user, size: 54, color: purple), const SizedBox(height: 12), const Text('Compte connecté', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)), const Text('La session CHAAMAS est authentifiée.')])));
}
